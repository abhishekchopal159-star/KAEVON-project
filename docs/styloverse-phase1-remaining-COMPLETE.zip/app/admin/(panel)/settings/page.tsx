import type { Metadata } from "next";

import AdminModulePlaceholder from "@/components/admin/AdminModulePlaceholder";

export const metadata: Metadata = {
  title: "Settings",
};

export default function AdminSettingsPage() {
  return (
    <AdminModulePlaceholder module="settings" />
  );
}

