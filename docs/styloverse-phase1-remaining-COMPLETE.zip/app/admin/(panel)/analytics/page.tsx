import type { Metadata } from "next";

import AdminModulePlaceholder from "@/components/admin/AdminModulePlaceholder";

export const metadata: Metadata = {
  title: "Analytics",
};

export default function AdminAnalyticsPage() {
  return (
    <AdminModulePlaceholder module="analytics" />
  );
}

