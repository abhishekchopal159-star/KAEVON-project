import type { Metadata } from "next";

import AdminModulePlaceholder from "@/components/admin/AdminModulePlaceholder";

export const metadata: Metadata = {
  title: "Discounts",
};

export default function AdminDiscountsPage() {
  return (
    <AdminModulePlaceholder module="discounts" />
  );
}

