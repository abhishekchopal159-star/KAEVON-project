import type { Metadata } from "next";

import AdminModulePlaceholder from "@/components/admin/AdminModulePlaceholder";

export const metadata: Metadata = {
  title: "Inventory",
};

export default function AdminInventoryPage() {
  return (
    <AdminModulePlaceholder module="inventory" />
  );
}

