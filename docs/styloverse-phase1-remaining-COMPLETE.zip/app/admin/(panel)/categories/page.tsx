import type { Metadata } from "next";

import AdminModulePlaceholder from "@/components/admin/AdminModulePlaceholder";

export const metadata: Metadata = {
  title: "Categories",
};

export default function AdminCategoriesPage() {
  return (
    <AdminModulePlaceholder module="categories" />
  );
}

