import type { ReactNode } from "react";
import ProtectedRoute from "@/components/auth/ProtectedRoute";

export default function AccountLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <ProtectedRoute>
      <section className="min-h-screen bg-[#faf8f5]">
        {children}
      </section>
    </ProtectedRoute>
  );
}