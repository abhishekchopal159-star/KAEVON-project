import type { Metadata } from "next";

import AccountLayout from "@/components/account/AccountLayout";
import WelcomeBanner from "@/components/account/WelcomeBanner";
import AccountStats from "@/components/account/AccountStats";
import ProfileCard from "@/components/account/ProfileCard";
import OrdersSection from "@/components/account/OrdersSection";
import RecommendedProducts from "@/components/account/RecommendedProducts";
import ActivityFeed from "@/components/account/ActivityFeed";
import { accountRecommendedProducts } from "@/lib/account-recommendations";

export const metadata: Metadata = {
  title: "My Dashboard",
  description:
    "Manage your Styloverse profile, orders, wishlist and account activity.",
};

export default function DashboardPage() {
  return (
    <AccountLayout>
      <div className="w-full">
        {/* Luxury welcome hero */}

        <section>
          <WelcomeBanner />
        </section>

        {/* Account statistics */}

        <section
          className="mt-6 md:mt-10"
          aria-label="Account overview"
        >
          <AccountStats />
        </section>

        {/* Main dashboard content */}

        <section className="mt-8 grid items-start gap-6 md:mt-12 md:gap-8 xl:grid-cols-[360px_minmax(0,1fr)]">
          {/* Left column */}

          <div className="space-y-6 md:space-y-8">
            <ProfileCard />

            <ActivityFeed />
          </div>

          {/* Right column */}

          <div className="min-w-0">
            <OrdersSection />
          </div>
        </section>

        {/* Recommended products */}

        <section
          className="mt-8 pb-6 md:mt-12 md:pb-10"
          aria-label="Recommended products"
        >
          <RecommendedProducts products={accountRecommendedProducts} />
        </section>
      </div>
    </AccountLayout>
  );
}
