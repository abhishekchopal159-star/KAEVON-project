import {
  arrayUnion,
  collection,
  doc,
  getDoc,
  onSnapshot,
  serverTimestamp,
  updateDoc,
  type DocumentData,
  type Unsubscribe,
} from "firebase/firestore";

import { db } from "@/lib/firebase";
import { canTransitionOrderStatus } from "@/lib/order-transitions";
import type {
  AdminCustomerSummary,
  AdminOrderAddress,
  AdminOrderItem,
  AdminOrderNote,
  AdminOrderRecord,
  AdminOrderStatus,
  AdminOrderTimelineEvent,
  AdminPaymentMethod,
  AdminPaymentStatus,
  AdminProfile,
} from "@/types/admin";
import {
  ADMIN_ORDER_STATUSES,
  ADMIN_PAYMENT_METHODS,
  ADMIN_PAYMENT_STATUSES,
} from "@/types/admin";

function readString(
  value: unknown,
  fallback = ""
) {
  return typeof value === "string"
    ? value.trim()
    : fallback;
}

function readNumber(value: unknown) {
  const parsed = Number(value);
  return Number.isFinite(parsed)
    ? parsed
    : 0;
}

function readBoolean(value: unknown) {
  return value === true;
}

function readRecord(
  value: unknown
): Record<string, unknown> {
  return value && typeof value === "object"
    ? (value as Record<string, unknown>)
    : {};
}

function readDate(
  value: unknown,
  fallback = ""
) {
  if (typeof value === "string") {
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime())
      ? fallback
      : parsed.toISOString();
  }

  if (value instanceof Date) {
    return value.toISOString();
  }

  if (value && typeof value === "object") {
    const timestamp = value as {
      toDate?: () => Date;
      seconds?: number;
    };

    if (typeof timestamp.toDate === "function") {
      return timestamp.toDate().toISOString();
    }

    if (typeof timestamp.seconds === "number") {
      return new Date(timestamp.seconds * 1000).toISOString();
    }
  }

  return fallback;
}

function normalizeOrderStatus(
  value: unknown
): AdminOrderStatus {
  const status = readString(value, "Confirmed");

  return ADMIN_ORDER_STATUSES.includes(
    status as AdminOrderStatus
  )
    ? (status as AdminOrderStatus)
    : "Confirmed";
}

function normalizePaymentMethod(
  value: unknown
): AdminPaymentMethod {
  const method = readString(value, "UPI");

  if (/^cod$/i.test(method)) {
    return "Cash on Delivery";
  }

  return ADMIN_PAYMENT_METHODS.includes(
    method as AdminPaymentMethod
  )
    ? (method as AdminPaymentMethod)
    : "UPI";
}

function normalizePaymentStatus(
  value: unknown
): AdminPaymentStatus {
  const status = readString(value, "Pending");

  if (status === "Paid") {
    return "Received";
  }

  return ADMIN_PAYMENT_STATUSES.includes(
    status as AdminPaymentStatus
  )
    ? (status as AdminPaymentStatus)
    : "Pending";
}

function normalizeOrderItems(
  value: unknown
): AdminOrderItem[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value.flatMap((entry, index) => {
    const item = readRecord(entry);
    const price = readNumber(
      item.price ?? item.salePrice
    );
    const imageList = Array.isArray(item.images)
      ? item.images
      : [];
    const firstImage = imageList.find(
      (image) => typeof image === "string"
    );

    return [
      {
        id: readString(
          item.id ?? item.productId ?? item.slug,
          `item-${index + 1}`
        ),
        name: readString(
          item.name ?? item.title,
          "Styloverse piece"
        ),
        image: readString(
          item.image ??
            item.imageUrl ??
            item.thumbnail ??
            firstImage
        ),
        price,
        originalPrice: readNumber(
          item.originalPrice ??
            item.compareAtPrice ??
            item.mrp ??
            price
        ),
        quantity: Math.max(
          1,
          Math.floor(readNumber(item.quantity) || 1)
        ),
        size: readString(
          item.size ?? item.selectedSize
        ),
        color: readString(
          item.color ?? item.selectedColor
        ),
      },
    ];
  });
}

function normalizeAddress(
  value: unknown
): AdminOrderAddress {
  const address = readRecord(value);

  return {
    addressLine1: readString(address.addressLine1),
    addressLine2: readString(address.addressLine2),
    landmark: readString(address.landmark),
    city: readString(address.city),
    state: readString(address.state),
    pincode: readString(address.pincode),
    country: readString(address.country, "India"),
  };
}

function normalizeTimeline(
  value: unknown
): AdminOrderTimelineEvent[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value.flatMap((entry, index) => {
    const event = readRecord(entry);
    const role = readString(event.actorRole, "system");

    return [
      {
        id: readString(event.id, `timeline-${index + 1}`),
        label: readString(event.label, "Order updated"),
        detail: readString(event.detail),
        createdAt: readDate(
          event.createdAt,
          new Date(0).toISOString()
        ),
        actorName: readString(
          event.actorName,
          "Styloverse system"
        ),
        actorRole:
          role === "admin" || role === "customer"
            ? role
            : "system",
      },
    ];
  });
}

function normalizeNotes(value: unknown): AdminOrderNote[] {
  if (!Array.isArray(value)) {
    return [];
  }

  return value.flatMap((entry, index) => {
    const note = readRecord(entry);
    const message = readString(note.message);

    if (!message) {
      return [];
    }

    return [
      {
        id: readString(note.id, `note-${index + 1}`),
        message,
        createdAt: readDate(
          note.createdAt,
          new Date(0).toISOString()
        ),
        authorId: readString(note.authorId),
        authorName: readString(
          note.authorName,
          "Styloverse administrator"
        ),
      },
    ];
  });
}

function normalizeAdminOrder(
  id: string,
  data: DocumentData
): AdminOrderRecord {
  const customer = readRecord(data.customer);
  const pricing = readRecord(data.pricing);
  const payment = readRecord(data.payment);
  const fulfilment = readRecord(data.fulfilment);
  const items = normalizeOrderItems(data.items);
  const subtotal = readNumber(pricing.subtotal);
  const deliveryCharge = readNumber(
    pricing.deliveryCharge
  );
  const total = readNumber(
    pricing.total ?? data.total
  );

  return {
    id: readString(data.id, id),
    userId: readString(data.userId),
    customerName: readString(
      customer.fullName,
      "Styloverse client"
    ),
    customerEmail: readString(
      customer.email,
      readString(data.userEmail)
    ),
    customerPhone: readString(customer.phone),
    createdAt: readDate(
      data.createdAt,
      new Date(0).toISOString()
    ),
    updatedAt: readDate(
      data.updatedAt,
      readDate(data.createdAt, new Date(0).toISOString())
    ),
    estimatedDelivery: readDate(data.estimatedDelivery),
    status: normalizeOrderStatus(data.status),
    paymentMethod: normalizePaymentMethod(
      payment.method ?? data.paymentMethod
    ),
    paymentStatus: normalizePaymentStatus(
      payment.status ?? data.paymentStatus
    ),
    paymentProvider: readString(
      payment.provider ?? data.paymentProvider,
      "Demo checkout"
    ),
    transactionId: readString(
      payment.transactionId ?? data.transactionId
    ),
    amountReceived: readNumber(
      payment.amountReceived ?? data.amountReceived
    ),
    paidAt: readDate(payment.paidAt ?? data.paidAt),
    refundAmount: readNumber(
      payment.refundAmount ?? data.refundAmount
    ),
    refundReference: readString(
      payment.refundReference ?? data.refundReference
    ),
    paymentVerified: readBoolean(
      payment.verified ?? data.paymentVerified
    ),
    total,
    subtotal: subtotal || Math.max(0, total - deliveryCharge),
    savings: readNumber(pricing.savings),
    deliveryCharge,
    itemCount: items.reduce(
      (total, item) =>
        total + item.quantity,
      0
    ),
    items,
    shippingAddress: normalizeAddress(data.shippingAddress),
    trackingId: readString(
      fulfilment.trackingId ?? data.trackingId
    ),
    shippingCarrier: readString(
      fulfilment.carrier ?? data.shippingCarrier
    ),
    timeline: normalizeTimeline(data.timeline),
    notes: normalizeNotes(data.adminNotes ?? data.notes),
  };
}

export type AdminOrderActor = Pick<
  AdminProfile,
  "uid" | "displayName"
>;

function createTimelineEvent(
  label: string,
  detail: string,
  actor: AdminOrderActor
): AdminOrderTimelineEvent {
  const createdAt = new Date().toISOString();

  return {
    id: `event-${Date.now()}-${Math.random()
      .toString(36)
      .slice(2, 8)}`,
    label,
    detail,
    createdAt,
    actorName: actor.displayName,
    actorRole: "admin",
  };
}

export async function updateAdminOrderStatus({
  orderId,
  currentStatus,
  status,
  actor,
  detail,
}: {
  orderId: string;
  currentStatus: AdminOrderStatus;
  status: AdminOrderStatus;
  actor: AdminOrderActor;
  detail?: string;
}) {
  const transition = canTransitionOrderStatus(
    currentStatus,
    status
  );

  if (!transition.allowed) {
    throw new Error(
      transition.reason ??
        "This status change is not allowed."
    );
  }

  await updateDoc(doc(db, "orders", orderId), {
    status,
    updatedAt: serverTimestamp(),
    timeline: arrayUnion(
      createTimelineEvent(
        status,
        detail ?? `Order moved to ${status}.`,
        actor
      )
    ),
  });
}

export async function addAdminOrderNote({
  orderId,
  message,
  actor,
}: {
  orderId: string;
  message: string;
  actor: AdminOrderActor;
}) {
  const safeMessage = message.trim();

  if (safeMessage.length < 2 || safeMessage.length > 600) {
    throw new Error("Admin note must contain 2 to 600 characters.");
  }

  const createdAt = new Date().toISOString();

  await updateDoc(doc(db, "orders", orderId), {
    adminNotes: arrayUnion({
      id: `note-${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 8)}`,
      message: safeMessage,
      createdAt,
      authorId: actor.uid,
      authorName: actor.displayName,
    } satisfies AdminOrderNote),
    updatedAt: serverTimestamp(),
  });
}

export async function updateAdminOrderFulfilment({
  orderId,
  trackingId,
  carrier,
  estimatedDelivery,
  actor,
}: {
  orderId: string;
  trackingId: string;
  carrier: string;
  estimatedDelivery: string;
  actor: AdminOrderActor;
}) {
  const safeTrackingId = trackingId.trim().slice(0, 80);
  const safeCarrier = carrier.trim().slice(0, 80);
  const safeDeliveryDate = readDate(estimatedDelivery);

  if (estimatedDelivery && !safeDeliveryDate) {
    throw new Error("Enter a valid estimated delivery date.");
  }

  await updateDoc(doc(db, "orders", orderId), {
    fulfilment: {
      trackingId: safeTrackingId,
      carrier: safeCarrier,
    },
    ...(safeDeliveryDate
      ? { estimatedDelivery: safeDeliveryDate }
      : {}),
    updatedAt: serverTimestamp(),
    timeline: arrayUnion(
      createTimelineEvent(
        "Delivery details updated",
        safeTrackingId
          ? `${safeCarrier || "Delivery partner"} · ${safeTrackingId}`
          : "Estimated delivery details were refreshed.",
        actor
      )
    ),
  });
}

export async function recordAdminCodCollection({
  orderId,
  amount,
  received,
  actor,
}: {
  orderId: string;
  amount: number;
  received: boolean;
  actor: AdminOrderActor;
}) {
  if (!Number.isFinite(amount) || amount < 0) {
    throw new Error("COD amount is invalid.");
  }

  const status: AdminPaymentStatus = received
    ? "COD Received"
    : "COD Collection Pending";
  const paidAt = received ? new Date().toISOString() : "";

  await updateDoc(doc(db, "orders", orderId), {
    paymentStatus: status,
    payment: {
      method: "Cash on Delivery",
      status,
      provider: "Manual COD collection",
      transactionId: "",
      amountReceived: received ? amount : 0,
      paidAt,
      refundAmount: 0,
      refundReference: "",
      verified: received,
      verificationSource: received
        ? "administrator_cod_confirmation"
        : "pending_collection",
    },
    updatedAt: serverTimestamp(),
    timeline: arrayUnion(
      createTimelineEvent(
        status,
        received
          ? "Cash collection was confirmed by the administrator."
          : "Cash collection was returned to pending.",
        actor
      )
    ),
  });
}

export async function getAdminProfile(
  userId: string
): Promise<AdminProfile | null> {
  const snapshot = await getDoc(
    doc(db, "users", userId)
  );

  if (
    !snapshot.exists() ||
    snapshot.data().role !== "admin"
  ) {
    return null;
  }

  const data = snapshot.data();

  return {
    uid: userId,
    displayName: readString(
      data.displayName ??
        data.name,
      "Styloverse Admin"
    ),
    email: readString(data.email),
    photoURL: readString(data.photoURL),
    role: "admin",
  };
}

export function subscribeToAdminStatus(
  userId: string,
  onStatusChange: (isAdmin: boolean) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  return onSnapshot(
    doc(db, "users", userId),
    (snapshot) => {
      onStatusChange(
        snapshot.exists() &&
          snapshot.data().role === "admin"
      );
    },
    (error) => onError?.(error)
  );
}

export function subscribeToAdminOrders(
  onOrders: (
    orders: AdminOrderRecord[]
  ) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  return onSnapshot(
    collection(db, "orders"),
    (snapshot) => {
      const orders = snapshot.docs
        .map((orderDocument) =>
          normalizeAdminOrder(
            orderDocument.id,
            orderDocument.data()
          )
        )
        .sort(
          (firstOrder, secondOrder) =>
            new Date(
              secondOrder.createdAt
            ).getTime() -
            new Date(
              firstOrder.createdAt
            ).getTime()
        );

      onOrders(orders);
    },
    (error) => onError?.(error)
  );
}

export function subscribeToAdminCustomers(
  onCustomers: (
    customers: AdminCustomerSummary[]
  ) => void,
  onError?: (error: Error) => void
): Unsubscribe {
  return onSnapshot(
    collection(db, "users"),
    (snapshot) => {
      const customers =
        snapshot.docs.map(
          (customerDocument) => {
            const data =
              customerDocument.data();

            return {
              id: customerDocument.id,
              displayName: readString(
                data.displayName ??
                  data.name,
                "Styloverse client"
              ),
              email: readString(
                data.email
              ),
              role: readString(
                data.role,
                "customer"
              ),
            };
          }
        );

      onCustomers(customers);
    },
    (error) => onError?.(error)
  );
}
